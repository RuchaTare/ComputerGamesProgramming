using UnityEngine;

public class Levelend : MonoBehaviour
{

    public GroundRestart GroundRestart;
    public GameObject LevelEndUI;

    public void LevelEnddisplay ()
    {
        LevelEndUI.SetActive(true);
    }
    public void OnTriggerEnter ()
    {
        GroundRestart.LevelEnd();
    }
}
