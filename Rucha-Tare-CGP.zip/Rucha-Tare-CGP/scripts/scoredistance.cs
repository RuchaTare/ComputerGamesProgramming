using UnityEngine;
using UnityEngine.UI;

public class scoredistance : MonoBehaviour
{
    public Transform Player;
    public Text distscore;
    void Update()
    {
        distscore.text = Player.position.z.ToString("0");
    }
}
