using UnityEngine;


public class PlayerMovement : MonoBehaviour
{
    //Declaring Required Variables
    public Rigidbody rb;
    public int ballspeed = 10;
    public int jumpspeed = 10;
    private bool playerisonground = true;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    void Update()
    {
        //Adding conditions so that the player could move right
        float Horizontalmove = Input.GetAxis("Horizontal");

        //Adding conditions so that the player could move left
        float Verticalmove   = Input.GetAxis("Vertical");

        Vector3 ballmove = new Vector3(Horizontalmove * Time.deltaTime, 0.0f, Verticalmove * Time.deltaTime); 
        rb.AddForce(ballmove * ballspeed);

        //Setting Space key to add jumps to the player

        if((Input.GetKey (KeyCode.Space)) && playerisonground)
                {
                    Vector3 balljump =  new Vector3(0.0f , 5.0f , 0.0f);
                    rb.AddForce(balljump * jumpspeed);
                     playerisonground = false;
                } 

                    
    }

    private void OnCollisionStay()
    {
        playerisonground = true;
    }  
        

       
        

        
            
}
