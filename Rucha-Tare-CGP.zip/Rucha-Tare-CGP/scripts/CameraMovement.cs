using UnityEngine;

public class CameraMovement : MonoBehaviour
{
    public Transform Player;
    public Vector3 cameraoffset;

    // Update is called once per frame
    void Update()
    {
        transform.position = Player.position + cameraoffset;
    }
}
