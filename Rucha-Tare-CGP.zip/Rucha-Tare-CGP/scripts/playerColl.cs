using UnityEngine;

public class playerColl : MonoBehaviour
{
    public PlayerMovement movement;
    //
    void onCollisionEnter (Collision Collisionvar)
    {
        if (Collisionvar.collider.tag == "Obstacles")
        {
            movement.enabled = false;
        }
    }
   
}
